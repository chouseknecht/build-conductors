#!/usr/bin/env python
# -*- coding: utf-8 -*-
import codecs
import datetime
import subprocess
import os
import re
import json
import sys
import io
from tzlocal import get_localzone  # python-tzlocal in epel
reload(sys)
sys.stdout = codecs.getwriter('utf8')(sys.stdout)
sys.stderr = codecs.getwriter('utf8')(sys.stderr)
sys.setdefaultencoding('utf8')


class ScanForInfo(object):

    def __init__(self):
        self.INDIR = '/scanin'
        self.OUTDIR = '/scanout'
        self.hostmount = '/host'
        cmount = []
        try:
            inc = os.listdir(self.INDIR)
            outc = os.listdir(self.OUTDIR)
            hc = os.listdir(self.hostmount)
            for x in os.listdir(self.INDIR):
                if os.path.isdir(os.path.join(self.INDIR, x)):
                    cmount.append(x)
            self.cname = cmount[0]
        except:
            print >> sys.stderr, "unable to find container id. or required volume mounts are not available"
            sys.exit(1)

    ##high level and helper functions##
    def get_inspect_info(self, container=None):
        try:
            if container:
              cmd = "chroot %s /bin/bash -c \"docker inspect %s\"" % (self.hostmount, container)
            else:
              cmd = "chroot %s /bin/bash -c \"docker inspect %s\"" % (self.hostmount, self.cname)
            output = subprocess.check_output([cmd], shell=True)
        except:
            print >> sys.stderr, "unable to do a docker inspect"
            sys.exit(1)
        else:
            return output

    def get_vuln_info(self):
        p = "/tmp/cveoutput"
        try:
            if not os.path.exists(p):
                os.mkdir(p)
            cmd = "oscapd-evaluate scan --no-standard-compliance --targets chroots-in-dir:///scanin --output %s" % (p)
            scan = subprocess.Popen([cmd], shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            scan.wait()
            jfcmd = "find /%s -mindepth 1 -name 'json'" % (p)
            jf = subprocess.check_output([jfcmd], shell=True)
            jf = jf.rstrip()
            with open(jf, 'r') as f:
                data = json.load(f)
            return data
        except:
            print >> sys.stderr, "unable to scan for vulns"
            sys.exit(1)

    def _p(self, *args):
        return os.path.join(self.INDIR, *args)

    def flatten_dicts(self):
        try:
            cd = {}
            for item in check_data:
                for k, v in item.iteritems():
                    cd[k] = v
            cd['parsed_date'] = sf.lb_time()
            cd['labels'] = labels
            if len(files) > 0:
              cd['files'] = files
            return cd
        except:
            print >> sys.stderr, "unable start json conversion process"
            sys.exit(1)

    def lb_time(self):
        try:
            now = datetime.datetime.now()
            local_tz = get_localzone()
            junkdate = local_tz.localize(now)
            t = str(junkdate)
            utcoffset = t[-6:]
            utcoffset = utcoffset.replace(':', '')
            lb_time = '{0:%Y}{0:%m}{0:%d}T{0:%H}:{0:%M}:{0:%S}.{1:03d}{2}'.format(now, now.microsecond // 1000, utcoffset)
            return lb_time
        except:
            print >> sys.stderr, "unable to get lb date"
            sys.exit(1)

    def as_time(self):
        return datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S")

    def pass_fail(self, ad):
        # all tests that required_for_certification must have True value
        l = []
        failing_checks = []
        results_d = {}
        for item in ad:
            if item['required_for_certification']:
                l.append(item['value'])
                if not item['value']:
                    failing_checks.append(item['name'])
        pass_fail = all(l)
        if pass_fail:
            final_decision = "PASS"
        else:
            final_decision = "FAIL"
            results_d['Custom'] = {"failing_checks": failing_checks}
            Results.append(results_d)
        return final_decision

    def json_out(self, ad, cd, final_decision, raw_openscap, ij, parsed_rpm_verification, run_time, run_time2, scanner_version, sum_layer_size_bytes):
        if final_decision == 'PASS':
            certification_date = sf.lb_time()
	else:
	    certification_date = ''
        try:
            container_id = ij['Id']
        except:
            pass
        all_tests = {
            'certification_date': certification_date,
            'assessments': ad,
            'atomic_scan_version': sf.rpm_version('atomic', 'host'),
            'isv_plugin_version': scanner_version,
            'openscap_version': sf.rpm_version('openscap', 'scanner'),
            'docker_version': sf.rpm_version('docker', 'host'),
            'certification_status': final_decision,
            'Scanner': 'isv_reporting',
            'Time': run_time2,
            'Scan Type': 'all',
            'Finished Time': sf.as_time(),
            'UUID': self._p(self.cname),
            'Successful': 'True',
            'run_time': run_time,
            'container_id': container_id,
            'sum_layer_size_bytes': sum_layer_size_bytes,
            'parsed_data': cd,
            'raw_data': {
                'openscap': raw_openscap,
                'docker_inspect': ij,
                'rpm_verify_problems': parsed_rpm_verification,
            }
        }
        # scanner plugin uses this
        if final_decision == 'FAIL':
            all_tests['Results'] = Results
        print (json.dumps(all_tests, ensure_ascii=False, encoding="utf-8", indent=4))
        try:
            p = "/scanout/%s" % (self.cname)
            if not os.path.exists(p):
                os.mkdir(p)
            with io.open(os.path.join(p, 'json'), 'w', encoding='utf8') as f:
                astr = json.dumps(all_tests, ensure_ascii=False, encoding="utf-8", indent=4)
                f.write(astr)
        except:
            print >> sys.stderr, "unable to save json to a file"
            pass

    ##generic reusable functions##
    def rpm_version(self, rpm, location):
        if location == 'host':  # host os
            rpmbin = self._p(self.hostmount, 'usr/bin/rpm')
            cmd = "%s --root %s -q %s --queryformat \"%%{VERSION}-%%{RELEASE}\"" % (rpmbin, self.hostmount, rpm)
        elif location == 'scanner':  # this container
            rpmbin = '/usr/bin/rpm'
            cmd = "%s -q %s --queryformat \"%%{VERSION}-%%{RELEASE}\"" % (rpmbin, rpm)
        else:  # from inside the mounted container
            rpmbin = self._p(self.cname, 'usr/bin/rpm')
            cmd = "%s --root %s -q %s --queryformat \"%%{VERSION}-%%{RELEASE}\"" % (rpmbin, self._p(self.cname), rpm)
        if os.path.exists(rpmbin):
            try:
                output = subprocess.check_output([cmd], shell=True)
            except:
                print >> sys.stderr, "unable to gather %s version" % (rpm)
                sys.exit(1)
            else:
                return output
        else:
            print >> sys.stderr, "unable to gather %s version" % (rpm)
            sys.exit(1)

    def di_get(self, ij, lookup, ad_desc, cd_name, location, required, url, flip, report=True):
        try:
            if location == 'label':
                result = ij['Config']['Labels'][lookup]
            elif location == 'top':
                result = ij[lookup]
            elif location == 'config':
                result = ij['Config'][lookup]
        except:
	    if report:
              if flip:
                  assessment_data.append({'name': ad_desc, 'value': True, "required_for_certification": required, "url": url})
              else:
                  assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
        else:
            if report:
              if location == 'label':
	           if len(str(result)) > 0:
                     labels.append({'name': cd_name, 'value': result})
              else:
	           if len(str(result)) > 0:
                     check_data.append({cd_name: result})
              assessment_data.append({'name': ad_desc, 'value': True, "required_for_certification": required, "url": url})
            else:
              return result

    def di_get_list(self, ij, lookup, ad_desc, cd_name, location, required, url, flip, report=True):
        results = []
        try:
            if location == 'label':
                result = ij['Config']['Labels'][lookup]
            elif location == 'top':
                result = ij[lookup]
            elif location == 'config':
                result = ij['Config'][lookup]
            elif location == 'RootFS':
                result = ij['RootFS'][lookup]

            for item in result:
                if item not in results:
                    results.append(item)
        except:
	    if report:
              assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
        else:
	    if report:
              if len(results) > 0:
                check_data.append({cd_name: results})
                assessment_data.append({'name': ad_desc, 'value': True, "required_for_certification": required, "url": url})
              else:
                assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
	    else:
	      return results

    def grab_file_contents(self, ad_desc, cd_name, location, required, url, key, flip):
        if os.path.isfile(location):
            try:
                with open(location, 'r') as fd:
                    data = fd.read().strip()
            except:
                assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
            else:
                files.append({'filename': cd_name, 'content': data, 'key': key})
                assessment_data.append({'name': ad_desc, 'value': True, "required_for_certification": required, "url": url})
        else:
            assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})

    ##functions with specific business logic or non-generalizble stpes below here##
    def rhel(self, ad_desc, cd_name, required, url):
        rhel_release_path = self._p(self.cname, 'etc/redhat-release')
        if os.path.isfile(rhel_release_path):
            try:
                with open(rhel_release_path, 'r') as fd:
                    line = fd.read().strip()
            except:
                assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
            else:
                if line.startswith('Red Hat Enterprise Linux Server'):
                    assessment_data.append({'name': ad_desc, 'value': True, "required_for_certification": required, "url": url})
                    check_data.append({cd_name: line})
                else:
                    assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
                    check_data.append({cd_name: line})
        else:
            assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
            check_data.append({cd_name: 'Unknown'})
    
    def licenses(self, ad_desc, cd_name, required, url):
        licenses_path = self._p(self.cname, 'licenses')
        if os.path.isdir(licenses_path):
            try:
                files = os.listdir(licenses_path)
            except:
                assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
            else:
                if len(files) > 0:
                    assessment_data.append({'name': ad_desc, 'value': True, "required_for_certification": required, "url": url})
                    check_data.append({cd_name: files})
                else:
                    assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
        else:
            assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})

    def rpm_verification(self, ad_desc, cd_name, required, url):
    ##break the standard.  don't store raw data and parsed data for this. instead just put the parsed data into raw data and completely /dev/null the raw data. 
        rpmbin = self._p(self.cname, 'usr/bin/rpm')
        if os.path.exists(rpmbin):
            outp = ''
            results = []
            try:
                cmd = "%s --root %s -Va || true" % (rpmbin, self._p(self.cname))
                outp = subprocess.check_output([cmd], shell=True)
            except:
                assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
            else:
                try:
                  rawout = outp.decode('utf-8')
                  lines = sorted(rawout.split('\n'))
                  rpmverifyinfo = []
                  for line in lines:
                      d = {}
                      line = line.strip()
                      if len(line) > 0:
                          s = filter(None, re.split("(^.*? )", line))
                          checkoutput = s[0]
                          checkoutput = checkoutput.strip()
                          other = s[1]
                          s = filter(None, re.split("(^.*?)(?=/)", other))
                          filetype = s[0]
                          filetype = filetype.strip()
                          if not filetype:
                              filetype = ""
                          cfile = s[1]
                          cfile = cfile.strip()
                          d['checkoutput'] = checkoutput
                          d['filetype'] = filetype
                          d['file'] = cfile
                          rpmverifyinfo.append(d)
                  for item in rpmverifyinfo:
                      if item['filetype'] != 'c':
                          if not item['file'].startswith('/proc') and not item['file'].startswith('/sys') and not item['file'].startswith('/dev'):
                              if '5' in item['checkoutput'] or 'M' in item['checkoutput']:
                                  l = "%s %s %s" % (item['checkoutput'], item['filetype'], item['file'])
                                  results.append(l)

                  if len(results) > 0:
                      assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
                  else:
                      assessment_data.append({'name': ad_desc, 'value': True, "required_for_certification": required, "url": url})
                  return results
                except:
                  assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
                  return results
        else:
            assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})

    def repos(self, ad_desc, cd_name, required, url):
        results = []
        yumbin = self._p(self.cname, 'usr/bin/yum')
        if os.path.exists(yumbin):
            output = ''
            try:
                cmd = "%s repolist -v | grep Repo" % (yumbin)
                output = subprocess.check_output([cmd], shell=True)
            except:
                assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
            else:
                try:
                  rawout = output.decode('utf-8')
                  lines = rawout.split('\n')
                  reposinfo = []
                  d = {}
                  for line in lines:
                      line = line.strip()
                      if len(line) > 0:
                          s = filter(None, re.split("(^.*?:)", line))
                          infotype = s[0].replace(":", "")
                          infotype = infotype.replace("Repo-", "")
                          infotype = infotype.strip()
                          value = s[1].strip()
                          if infotype == 'id':
                              if len(d) > 0:
                                  reposinfo.append(d)
                              d = {infotype: value}
                          else:
                              d[infotype] = value
                  reposinfo.append(d)
                  for repo in reposinfo:
                      results.append({'name': repo['name'], 'baseurl': repo['baseurl'], 'id': repo['id'], 'updated': repo['updated'], 'pkgs': repo['pkgs'], 'size': repo['size'], 'expire': repo['expire']})
                  assessment_data.append({'name': ad_desc, 'value': True, "required_for_certification": required, "url": url})
		  if len(results) > 0:
                      check_data.append({cd_name: results})
                except:
                  assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
        else:
            assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})

    def srpmformat (self, rpm):
        rpmbin = self._p(self.cname, 'usr/bin/rpm')
        if os.path.exists(rpmbin):
            try:
                cmd = "%s --root %s -q %s --queryformat \"%%{EPOCH}|%%{SOURCERPM}|%%{VERSION}\n\"" % (rpmbin, self._p(self.cname), rpm)
                output = subprocess.check_output([cmd], shell=True)
	    except:
		return ("", "")
            else:
                try:
    		  if len(output.strip()) > 0:
                      output = output.strip()
                      if len(output) > 0 and output.count('|') == 2:
                          s = output.split("|")
                          epoch = str(s[0])
                          srpm = str(s[1])
                          version = str(s[2])
                          try:
                              stripend = re.search(r'.+?(?=-[0-9].*)', srpm)
                              end = re.search(r'(-[0-9].*)', srpm)
                              endchop = end.group(0)[1:-4]
                              bgname = stripend.group(0)
                              if epoch != "(none)":
                                  bgnerva = "%s-%s:%s" %( bgname, epoch, endchop)
                              else:   
                                  bgnerva = "%s-0:%s" %( bgname, endchop)
                          except:
                              bgname = ""
                              bgnerva = ""
			  return (bgname, bgnerva)
                except:
	          return ("", "")
        else:
	    return ("", "")


    def rpms(self, ad_desc, cd_name, required, url):
        results = []
        blresults = []
        rpmbin = self._p(self.cname, 'usr/bin/rpm')
        if os.path.exists(rpmbin):
            try:
                cmd = "%s --root %s -qa --queryformat \"%%{NAME}|%%{VERSION}|%%{ARCH}|%%{RELEASE}|%%{SIGPGP:pgpsig}|%%{SUMMARY}|%%{NAME}-%%{VERSION}-%%{RELEASE}.%%{ARCH}\n\"" % (rpmbin, self._p(self.cname))
                output = subprocess.check_output([cmd], shell=True)
            except:
                assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
            else:
                try:
                  lines = sorted(output.split('\n'))
                  for ln in lines:
                      if len(ln.strip()) > 0:
                          ln = ln.strip()
                          if len(ln) > 0 and ln.count('|') == 6:
                              s = ln.split("|")
                              rname = str(s[0])
                              version = str(s[1])
                              arch = str(s[2])
                              release = str(s[3])
                              gpg = str(s[4].split()[-1])
                              summary = unicode(s[5], "utf-8")
                              nvra = str(s[6])
                              if rname != 'gpg-pubkey':
			        try:
			            srpminfo = sf.srpmformat(rname)
			        except:
                                    srpm_nevra = ""
                                    srpm_name = ""
			        else:
				    if srpminfo:
                                        srpm_nevra = srpminfo[1]
                                        srpm_name = srpminfo[0]
				    else:
                                        srpm_nevra = ""
                                        srpm_name = ""
                                x = dict([("name", rname), ("version", version), ("architecture", arch), ("release", release), ("nvra", nvra), ("gpg", gpg), ("summary", summary), ("srpm_nevra", srpm_nevra), ("srpm_name", srpm_name)])
                                results.append(x)
                                blresults.append(nvra)
                  assessment_data.append({'name': ad_desc, 'value': True, "required_for_certification": required, "url": url})
	          if len(results) > 0:
                    check_data.append({cd_name: results})
                except:
                  assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
        else:
            assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})

    def privilege(self, ij, ad_desc, cd_name, required, url):
        try:
            result = ' '.join(ij['Config']['Cmd'])
        except:
            try:
                result = ' '.join(ij['Config']['Entrypoint'])
            except:
                assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
	    else:
	        if len(str(result)) > 0:
                  check_data.append({cd_name: result})
                assessment_data.append({'name': ad_desc, 'value': True, "required_for_certification": required, "url": url})
        else:
	    if len(str(result)) > 0:
              check_data.append({cd_name: result})
            if '--privileged' in result:
                assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
            else:
                assessment_data.append({'name': ad_desc, 'value': True, "required_for_certification": required, "url": url})

    def user(self, ij, ad_desc, cd_name, required, url):
        try:
            result = ij['Config']['User']
        except:
            assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
        else:
	    if len(str(result)) > 0:
              check_data.append({cd_name: result})
            if result == 'root':
                assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
            else:
                assessment_data.append({'name': ad_desc, 'value': True, "required_for_certification": required, "url": url})

    def di_get_help(self, ij, lookup, ad_desc, cd_name, required, url):
        try:
            result = ij['Config']['Labels'][lookup]
        except:
            assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
            return self._p(self.cname, 'help.1'), '/help.1'
        else:
	    if len(str(result)) > 0:
              labels.append({'name': cd_name, 'value': result})
            assessment_data.append({'name': ad_desc, 'value': True, "required_for_certification": required, "url": url})
            return self._p(self.cname, result), result

    def di_repodigest_id(self, ij, ad_desc, cd_name, required, url):
        try:
            result = sf.di_get_list(ij, 'RepoDigests', 'none', 'none', 'top', False, 'none', False, False)
            result = result[0].split('@')[1]
        except:
            assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
        else:
            assessment_data.append({'name': ad_desc, 'value': True, "required_for_certification": required, "url": url})
	    if len(str(result)) > 0:
              check_data.append({cd_name: result})

    def repotags(self, ij, ad_desc, cd_name, required, url):
        results = []
        try:
            for tag in ij['RepoTags']:
                if tag not in results:
                    results.append(tag)
        except:
            assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
        else:
            try:
              if len(results) ==  0:
                assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
              elif len(results) == 1:
                str = " ".join(results)
                if re.search(':latest', str):
                  check_data.append({cd_name: results})
                  assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
                else:
                  check_data.append({cd_name: results})
                  assessment_data.append({'name': ad_desc, 'value': True, "required_for_certification": required, "url": url})
              elif len(results) == 2:
                str = " ".join(results)
                if re.search(':latest', str):
                  check_data.append({cd_name: results})
                  assessment_data.append({'name': ad_desc, 'value': True, "required_for_certification": required, "url": url})
                else:
                  check_data.append({cd_name: results})
                  assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
              else:
                  check_data.append({cd_name: results})
                  assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
            except:
              assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})

    def layers(self, ad_desc, cd_name, required, url):
        results = []
        try:
            cmd = "chroot %s /bin/bash -c \"docker history --no-trunc -q %s\"" % (self.hostmount, self.cname)
            output = subprocess.check_output([cmd], shell=True)
        except:
            assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
        else:
            try:
              for layer in output.split(os.linesep):
                  if len(layer) > 0:
                      results.append(layer)
              if len(results) > 1:
                  assessment_data.append({'name': ad_desc, 'value': True, "required_for_certification": required, "url": url})
              else:
                  assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
            except:
              assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})

    def layer_list(self, ij, cd_name):
        try:
	    results = sf.di_get_list(ij, 'Layers', 'none', 'none', 'RootFS', False, 'none', False, False)
        except:
            pass
        else:
            if len(results) > 0:
              check_data.append({cd_name: results})

    def vuln(self, raw_openscap, ad_desc, cd_name, required, url):
        results = []
        try:
            for vuln in raw_openscap['Vulnerabilities']:
 		if vuln['Severity'] == 'Critical':
                	if vuln['Custom']['RHSA ID'] not in results:
                		results.append(vuln['Custom']['RHSA ID'])
        except:
            assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
        else:
            if len(results) > 0:
                assessment_data.append({'name': ad_desc, 'value': False, "required_for_certification": required, "url": url})
            else:
                assessment_data.append({'name': ad_desc, 'value': True, "required_for_certification": required, "url": url})

    def scanner_version(self, ij):
        try:
            result = ij['Config']['Labels']['version']
        except:
            result = 'Unknown'
            return result
        else:
            return result

    def other_labels(self, ij, labels):
	labels_we_care_about = []
        try:
	    alllabels = ij['Config']['Labels']
        except:
            pass
        else:
            try:
	      for item in labels:
		  labels_we_care_about.append(item['name'])
              for label in alllabels:
		  if label not in labels_we_care_about:
		      sf.di_get(ij, label, label + '_label_exists', label, 'label', False, docurl + label + '_label_exists', False)
            except:
              pass

if __name__ == '__main__':
    sf = ScanForInfo()
    run_time = sf.lb_time()
    run_time2 = sf.as_time()
    inspect = sf.get_inspect_info()
    j = json.loads(inspect)
    ij = j[0]
    scaninspect = sf.get_inspect_info('registry.rhc4tp.openshift.com/connect-tools/plugin')
    scanj = json.loads(scaninspect)
    scanij = scanj[0]
    raw_openscap = sf.get_vuln_info()
    check_data = []
    assessment_data = []
    files = []
    labels = []
    Results = []
    docurl = "http://nope.nope/nope.html#"
    sf.rhel('is_rhel', 'os', True, docurl + 'is_rhel')
    sf.licenses('has_licenses', 'licenses', True, docurl + 'licenses')
    parsed_rpm_verification = sf.rpm_verification('rpm_verify_successful', 'rpm_verify_problems', True, docurl + 'rpm_verify_successful')
    sf.repos('repo_list_successful', 'repos', False, docurl + 'repo_list_successful')
    sf.rpms('rpm_list_successful', 'rpm_manifest', True, docurl + 'rpm_list_successful')
    sf.privilege(ij, 'not_running_privileged', 'command', True, docurl + 'not_running_privileged')
    sf.user(ij, 'not_running_as_root', 'user', True, docurl + 'not_running_as_root')
    sf.di_get(ij, 'name', 'name_label_exists', 'name', 'label', True, docurl + 'name_label_exists', False)
    sf.di_get(ij, 'vendor', 'vendor_label_exists', 'vendor', 'label', True, docurl + 'vendor_label_exists', False)
    sf.di_get(ij, 'version', 'version_label_exists', 'version', 'label', True, docurl + 'version_label_exists', False)
    sf.di_get(ij, 'release', 'release_label_exists', 'release', 'label', True, docurl + 'release_label_exists', False)
    sf.di_get(ij, 'run', 'run_label_exists', 'run', 'label', False, docurl + 'run_label_exists', False)
    sf.di_get(ij, 'stop', 'stop_label_exists', 'stop', 'label', False, docurl + 'stop_label_exists', False)
    sf.di_get(ij, 'Size', 'Size_exists', 'Size', 'top', False, docurl + 'Size_exists', False)
    sf.di_get(ij, 'VirtualSize', 'VirtualSize_exists', 'virtual_size', 'top', False, docurl + 'VirtualSize_exists', False)
    sf.di_get(ij, 'Architecture', 'Architecture_exists', 'architecture', 'top', False, docurl + 'Architecture_exists', False)
    sf.di_get(ij, 'Author', 'Author_exists', 'author', 'top', False, docurl + 'Author_exists', False)
    sf.di_get(ij, 'Comment', 'Comment_exists', 'comment', 'top', False, docurl + 'Comment_exists', False)
    sf.di_get(ij, 'Container', 'Container_exists', 'container', 'top', False, docurl + 'Container_exists', False)
    sf.di_get(ij, 'Created', 'Created_exists', 'created', 'top', False, docurl + 'Created_exists', False)
    sf.di_get(ij, 'DockerVersion', 'DockerVersion_exists', 'docker_version', 'top', False, docurl + 'DockerVersion_exists', False)
    sf.di_get(ij, 'Id', 'Id_exists', 'docker_image_id', 'top', False, docurl + 'Id_exists', False)
    sf.di_repodigest_id(ij, 'RepoDigests_exists', 'docker_image_digest', False, docurl + 'RepoDigests_exists')
    hf = sf.di_get_help(ij, 'help', 'help_label_exists', 'help', False, docurl + 'help_label_exists')
    sf.grab_file_contents('dockerfile_exists', '/root/buildinfo', sf._p(sf.cname, 'root/buildinfo'), False, docurl + 'dockerfile_exists', 'buildfile', False)
    sf.grab_file_contents('atomic_help_exists', hf[1], hf[0], True, docurl + 'atomic_help_exists', 'help', False)
    sf.repotags(ij, 'good_tags', 'repo_tags', True, docurl + 'good_tags')
    sf.di_get_list(ij, 'Env', 'Env_exists', 'env_variables', 'config', False, docurl + 'Env_exists', False, True)
    sf.di_get_list(ij, 'ExposedPorts', 'ExposedPorts_exists', 'ports', 'config', False, docurl + 'ExposedPorts_exists', False, True)
    sf.other_labels(ij, labels)
    sf.layers('good_layer_count', 'layers', True, docurl + 'good_layer_count')
    sf.layer_list(ij, 'layers')
    sf.vuln(raw_openscap, 'free_of_critical_vulnerabilities', 'vulnerabilities', True, docurl + 'free_of_critical_vulnerabilities')
    scanner_version = sf.scanner_version(scanij)
    sum_layer_size_bytes =  sf.di_get(ij, 'Size', 'none', 'none', 'top', False, 'none', False, False)
    # print check_data
    # print assessment_data
    cdjd = sf.flatten_dicts()
    final_decision = sf.pass_fail(assessment_data)
    sf.json_out(assessment_data, cdjd, final_decision, raw_openscap, ij, parsed_rpm_verification, run_time, run_time2, scanner_version, sum_layer_size_bytes)
