Test cases and corresponding containers for RHC4TP scanning plugin

Testing Assessments:
These containers are build from Dockerfiles located inside directories with $assessment_name.  All the directories
are located in the assessments directory.

| assessment | container |
| -------- | -------- |


Testing for Regressions:

These containers are build from Dockerfiles located inside directories with the name specified in the table. .  All the directories 
are located in the assessments directory.

| container / test case | tests for regression fixed by commitID |
| -------- | -------- |
| r1      |  commit 63bf6fa92ffdef830f5126451a1a3c5d1885afae  |


