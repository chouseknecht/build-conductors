#/bin/bash
echo "Copying example_plugin configuration file to host filesystem..."
cp -v /isv_reporting /host/etc/atomic.d/
