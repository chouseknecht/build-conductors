Building the plugin
===================
	
**Prereq:** 
You must build this container on a RHEL7 VM with proper entitlements. This is required because containers piggy back off of host RHEL subscription.  See [this](https://access.redhat.com/documentation/en/red-hat-enterprise-linux-atomic-host/7/single/getting-started-with-containers/#get_started_with_docker_formatted_container_images) and [this](https://access.redhat.com/solutions/1443553) for more info.  More specifically, 

		When you use yum install within a container to add packages, the container automatically has access to entitlements available from the RHEL 7 host, so it can get RPM packages from any repository enabled on that host.
		NOTE: In order for a container to be able to access repositories, the host system must be subscribed either directly to RHSM or to a Satellite 6 system. Satellite 5 and RHN Classic do not provide repository access inside a container and are thus unsupported for use inside the container.


Youll want the following channels (assuming AWS box):
 
  - rhui-REGION-rhel-server-extras/7Server/x86_64
  - rhui-REGION-rhel-server-optional/7Server/x86_64
  - rhui-REGION-rhel-server-rh-common/7Server/x86_64 
  - rhui-REGION-client-config-server-7/x86_64
  - rhui-REGION-rhel-server-supplementary/7Server/x86_64
  - rhui-REGION-rhel-server-releases/7Server/x86_64
  - epel/x86_64
  - rhel-7-server-rpms/7Server/x86_64 
  - rhel-ha-for-rhel-7-server-rpms/7Server/x86_64

Something like the following should be done (assuming AWS rhel7 image):

	yum -y install https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
	subscription-manager register
	subscription-manager attach --auto
	yum-config-manager --enable rhui-REGION-client-config-server-7
	yum-config-manager --enable rhui-REGION-rhel-server-extras
	yum-config-manager --enable rhui-REGION-rhel-server-optional
	yum-config-manager --enable rhui-REGION-rhel-server-releases
	yum-config-manager --enable rhui-REGION-rhel-server-rh-common
	yum-config-manager --enable rhui-REGION-rhel-server-supplementary
	yum -y install docker atomic git unzip
	systemctl enable docker
	systemctl start docker

	
Its not enough to just use Amazons repos (or satellite in phx?) even though you have access to all the channels with all the packages you need.  It seems you have to register the box no matter what.  I suppose you could also register the box and use upstream repos instead of amazon/satellite repos which may be cleaner but slower. 


**Building:**

    git clone $this_repo #or scp a zip over and unzip it
    cd RHC4TP_scanning_plugin
    docker build -t plugin .
    docker tag plugin registry.rhc4tp.openshift.com/connect-tools/plugin
    atomic install plugin

Doing a scan
------------

    atomic --debug scan --scanner plugin $ISVREG/p16089968451dbc9e226ead18831461e20985a36c8/rhel7g:superGood

Hacking on the plugin (using an actual container given to us by somebody)
---------------------

     mkdir -p /tmp/scanout
     mkdir -p /tmp/foobar
     mkdir -p /tmp/scanin
     cd RHC4TP_scanning_plugin 
     cp rh_isv.py /tmp/foobar
     #pull by tag and by digest
     docker pull $ISVREG/p16089968451dbc9e226ead18831461e20985a36c8/rhel7g:superGood
     docker pull $ISVREG/p16089968451dbc9e226ead18831461e20985a36c8/rhel7g@sha256:f8094fb0a4c1aebb4fe4f7ae88c30e3f01f65eb2c350cb916c67ba5513cc6591
     #get the sha256 hash of the image
     docker images --no-trunc  
     rm -Rf /tmp/scanin/*
     mkdir /tmp/scanin/3033b6a756c1ef06f2fc6eface6584db5d083d024bc853d4287d218099f53f5d
     atomic mount $ISVREG/p16089968451dbc9e226ead18831461e20985a36c8/rhel7g:superGood /tmp/scanin/3033b6a756c1ef06f2fc6eface6584db5d083d024bc853d4287d218099f53f5d
     docker run -it --privileged -v /etc/localtime:/etc/localtime -v /tmp/scanin:/scanin -v /tmp/scanout:/scanout:rw,Z -v /:/host -v /tmp/foobar:/foobar -v /etc/oscapd:/etc/oscapd:ro plugin /bin/bash
    
     python /foobar/rh_isv.py
     vim /foobar/rh_isv.py
     python /foobar/rh_isv.py #notice your changes

$ISVREG = rhc4tp-registry.dev.a1.vary.redhat.com #or similar 

If you want to do a real scan from the host with the edited code can edit `/etc/atomic.d/isv_reporting` so that `args: ['python', '/foobar/rh_isv.py']` then run the scan command from above.

Be sure to update Version in the Dockerfile whenever you commit your changes to the repo. Also be sure to update sample_output.json to include your changes.  


Interpreting the output
=======================

Top level key, value pairs:

- certification_date - The date and time your container passed the certification tests.  Only populated if your container meets all of the requirements. 

- Time,Finished Time, run_time, parsed_date  - The date and time your scan was ran and completed, ran and parsed in different formats.    

- certification_status - PASS or FAIL.  Ultimate decision on certification

- Scanner, Scan Type - The name of the scanning plugins that ran. 

- Successful - Whether or not the scan completed.  See certification_status for PASS/FAIL results.  

- error - If the scan was ran but the rh specific control.py script or some other third party script and it failed to complete a message about why will be here. In error situations the only fields that will always be set are Succesful = False and this field to a descriptive error message.  If the scan completed and Successful = True this field will not be present in the output.  

- container_id - Docker Id of your container. May be used for unique key tracking. 

- UUID - mount point of the container you are scanning. 

- *_version - The version of the plugins and other applications that are assisting with the scan.  


Top level arrays:

- assessments - List of objects containing key value pairs.  Every object in the list is for a specific requirement or data gathering operation.  The key values inside of the object let you know the name of the test, whether or not it passed (value), whether or not you are required to pass it for certification and gives a URL where you can learn more about the check. Your goal here is to get all objects that have a required_for_certification = true to also have a value = true. When that happens certification_status = PASS.  

- parsed_data - The key value pairs, lists and arrays of data in this data structure is the 'user friendly' parsed output of the checks that ran.  

- raw_data - Contains un-parsed 'non-user friendly' data that other checks use to populate their parsed_data or assessments info.  

- Results - Contains a list of a single object.  'Custom' is the key whose value is an object with a key of 'failing_checks' whose value is a list of checks that are failing.  This data format is needed so that atomic scan spit out a high level summary of 'The following results were found' if certification_status = FAIL.  If certification_status = True there will not be a Results object and the output of atomic scan will show a 'passed the scan' message instead of the 'The following results were found' message. 


An example....

 1. A requirement is that a container must not run its command as `root`.  
 2. A function is ran to gather `docker inspect` data.  Its full output is shoved into `raw_data docker_inspect`. 
 3. A function `user` is ran to gather the User info out of that raw `docker inspect` data.  
 4. The User data that is found is placed into `parsed_data user` .  It could for example have the value of `nginx`.  
 5. An evaluation happens that notes that `nginx != root`  and because of this  `assesments not_running_as_root value` is set to `True`.  Since this is a requirement and not a data gathering operation `assessments required_for_certification` is set to `True`.  A URL is also added so you can get more information about the requirement.  


Remember you want all objects inside of assessments that have required_for_certification = true to have value = true.   When you meet those requirements your container will get certified.  

